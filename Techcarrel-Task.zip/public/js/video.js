
$(function () {
    "use strict";
    $(".galleryVid .videoTag").click(function () {
        var $srcvid = $(this).find("source").attr("src"); 
        $(".showvideo").fadeIn();
        $(".vid-show video").attr("src", $srcvid);
        $(this).play();

    });
    
    $(".close, .overlay").click(function () {
        $(".showvideo").fadeOut();
       $('video').trigger('pause');
    });
    
});



//match height of news cards
var maxHeight = 0;
$(".galleryVid").each(function () {
if ($(this).height() > maxHeight) { maxHeight = $(this).height(); }
});
$(".galleryVid").height(maxHeight);