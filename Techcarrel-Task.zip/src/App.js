import logo from './logo.svg';
import './App.css';
import Header from './component/navbar';
import ImageGrid from './component/imageGrid';
import Video from './component/video';
import Error404 from './component/Error404';
import Footer from  './component/footer';
import Tab from './component/Tab';
import PopupVideo from './component/popupVideo';
import { BrowserRouter, BrowserRouter as Router,Link, Route, Routes } from 'react-router-dom';
function App() {
  return (
    <>
    
  <BrowserRouter>
    <Header/>
        <Routes>
          <Route  path="/" element={<ImageGrid/>}/>
          <Route  path="/popupVideo" element={<PopupVideo/>}/>
          <Route path="*" element={<Error404/>}/>
        </Routes>  
      </BrowserRouter>
    </>
    );
}

export default App;
