import React,{useState,useEffect} from "react";
import axios from 'axios';
function ImageGrid() {
 const [data,setData]=useState([]);
    /*const List=()=>{
        fetch('https://pixabay.com/api/?key=28723975-ee704535ca2a03a32906b925f&q=yellow+flowers&image_type=photo')
        .then((result)=>{
            result.json().then((resp)=>{
                setData(resp);
            })
        })
    }
    useEffect(()=>{
      List();
  },[]);*/
  const getCovidData=async()=>{
    try{
    const res=await fetch('https://pixabay.com/api/?key=28723975-ee704535ca2a03a32906b925f&q=yellow+flowers&image_type=photo');
    const actualData=await res.json();
    /*console.log(actualData.statewise[0]);*/
    setData(actualData.hits);   
    }catch(err){
    console.log(err);
    }
    }
    useEffect(() => {
    getCovidData();
    }, []);
  return (
    <>
    <div className="container">
  
  <h1>Simple Image Gallery with magnific-popup.js</h1>
  
    <section className="img-gallery-magnific">
      {
        data.map((item)=>{
          return(
           <div className="magnific-img">
          <a className="image-popup-vertical-fit" href={item.largeImageURL} title="9.jpg">
            <img src={item.largeImageURL} alt="9.jpg" />
            <i className="fa fa-search-plus" aria-hidden="true"></i>
          </a>
        </div>
          )
        })
      }
          
     

      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/400/?random" title="10.jpg">
          <img src="https://unsplash.it/900/?random" alt="10.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
    
      {/*
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/900/?random" title="10.jpg">
          <img src="https://unsplash.it/900/?random" alt="10.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/902" title="3.jpg">
          <img src="https://unsplash.it/902/" alt="3.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/901" title="4.jpg">
          <img src="https://unsplash.it/901" alt="4.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/888/?random" title="1.jpg">
          <img src="https://unsplash.it/888/?random" alt="1.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/931/?random" title="2.jpg">
          <img src="https://unsplash.it/931/?random" alt="2.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/908/?random" title="5.jpg">
          <img src="https://unsplash.it/908/?random" alt="5.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/978/?random" title="6.jpg">
          <img src="https://unsplash.it/978/?random" alt="6.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/857/?random" title="7.jpg">
          <img src="https://unsplash.it/857/?random" alt="7.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/905/?random" title="8.jpg">
          <img src="https://unsplash.it/905/?random" alt="8.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/1230/?random" title="12.jpg">
          <img src="https://unsplash.it/1230/?random" alt="12.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/800/?random" title="13.jpg">
          <img src="https://unsplash.it/800/?random" alt="13.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/930/?random" title="14.jpg">
          <img src="https://unsplash.it/930/?random" alt="14.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/999/?random" title="15.jpg">
          <img src="https://unsplash.it/999/?random" alt="15.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
      </div>
      <div className="magnific-img">
        <a className="image-popup-vertical-fit" href="https://unsplash.it/897/?random" title="16.jpg">
          <img src="https://unsplash.it/897/?random" alt="16.jpg" />
          <i className="fa fa-search-plus" aria-hidden="true"></i>
        </a>
  </div>*/}

    </section>
    <div className="clear"></div>


</div>

    </>
  );
}

export default ImageGrid;
