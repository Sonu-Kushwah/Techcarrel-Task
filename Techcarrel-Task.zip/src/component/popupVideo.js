import React, { useState, useEffect } from "react";
function PopupVideo() {
  const [data, setData] = useState([]);
  const getCovidData = async () => {
    try {
      const res = await fetch(
        "https://pixabay.com/api/videos/?key=28723975-ee704535ca2a03a32906b925f&q=yellow+flowers"
      );
      const actualData = await res.json();
      console.log(actualData.hits);
      var resp=actualData.hits;
      console.log("resp",resp);
      setData(resp);
    } catch (err) {
      console.log(err);
    }
  };
  useEffect(() => {
    getCovidData();
  }, []);

  console.log('data',data.videos);
  return (
    <>
      <div class="vid-slider">
        <div class="vid-wrapper">
          {data.map((item) => {
            console.log('videos',item.videos.large.url);
            return (
              <div class="vid item">
                <iframe
                  width="213"
                  height="119"
                  src={item.videos.large.url}
                  frameborder="0"
                  allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                  allowfullscreen
                ></iframe>
              
              </div>
            );
          })}
        </div>
      </div>
      <div class="video-popup">
        <div class="iframe-wrapper">
          <iframe
            width="400"
            height="300"
            src=""
            frameborder="0"
            allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
            allowfullscreen
          ></iframe>
          <span class="close-video"></span>
        </div>
      </div>
    </>
  );
}

export default PopupVideo;
