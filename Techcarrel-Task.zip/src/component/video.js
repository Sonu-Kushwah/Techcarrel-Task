import React, { useState } from "react";
import Button from "react-bootstrap/Button";
import Modal from "react-bootstrap/Modal";
function Video() {
  return (
    <>
    <div className="container">
    <div class="gallery popup">
        
        <div class="galleryVid">
          <video width="250px" height="200px" class="videoTag">
            <source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4" />
            Your browser does not support HTML5 video.
          </video>
          <div class="desc" >Video Title</div>
        </div>

        <div class="galleryVid">
          <video width="250px" height="200px" class="videoTag">
            <source src="https://www.w3schools.com/tags/movie.mp4" type="video/mp4" />
            Your browser does not support HTML5 video.
          </video>
          <div class="desc" >Add a description of the image here</div>
        </div>
      </div>
      <div class="showvideo">
        <div class="overlay"></div>
        <div class="vid-show">
          <span class="close">X</span>
          <video width="600" controls>
            <source src="" type="video/mp4" />
            Your browser does not support HTML5 video.
          </video>
        </div>
      </div>
    </div>
    </>
  );
}

export default Video;
