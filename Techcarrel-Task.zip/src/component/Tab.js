import Tab from "react-bootstrap/Tab";
import Tabs from "react-bootstrap/Tabs";
import ImageGrid from "./imageGrid";
import Video from "./video";
import PopupVideo from "./popupVideo";

function UncontrolledExample() {
  return (
    <>
      <div className="container">
        <div className="tabOuterBox">
          <div className="tab_box">
            <Tabs
              defaultActiveKey="profile"
              id="uncontrolled-tab-example"
              className="mb-3"
            >
            <Tab eventKey="home" title="Image">
                <ImageGrid />
              </Tab>
            <Tab eventKey="profile" title="Video">
                <PopupVideo/>
            </Tab>
            </Tabs>
          </div>
        </div>
      </div>
    </>
  );
}

export default UncontrolledExample;
